﻿using System;
namespace LMS.Models.LMSModels
{
    public class GPA
    {
        public double gpa;

        public GPA(double gpa)
        {
            this.gpa = gpa;
        }
    }
}
